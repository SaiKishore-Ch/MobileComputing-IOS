//
//  ItemInfoViewController.swift
//  Chowdam_GroceryApp
//
//  Created by Chowdam,Sai Kishore on 4/12/22.
//

import UIKit

class ItemInfoViewController: UIViewController {

    var itemDetails : GroceryItem?
    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    
    @IBOutlet weak var showItemInfoAction: UIButton!
    
    @IBOutlet weak var itemInfoOutlet: UITextView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.title = itemDetails?.itemName
        itemInfoOutlet.isHidden = true
        var ig = itemDetails?.itemImage
        itemImageViewOutlet.image = UIImage(named: ig!)
        let orgImageFrame = itemImageViewOutlet.frame
        let widthShrink: CGFloat = 30
        let heightShrink: CGFloat = 30
        let newFrame = CGRect(
        x: itemImageViewOutlet.frame.origin.x + widthShrink,
        y: itemImageViewOutlet.frame.origin.y + heightShrink,
        width: itemImageViewOutlet.frame.width - widthShrink,
        height: itemImageViewOutlet.frame.height - heightShrink)
        itemImageViewOutlet.frame = newFrame
        UIView.animate(withDuration: 1.0, delay: 0.7, usingSpringWithDamping: 0.3, initialSpringVelocity: 30.0,  animations: {
                        self.itemImageViewOutlet.frame = orgImageFrame
                    })
            
        }
    
    @IBAction func buttonGetInfo(_ sender: Any) {
        itemInfoOutlet.isHidden = false
        itemInfoOutlet.text = itemDetails?.itemInfo
        
        
    }
}
    



