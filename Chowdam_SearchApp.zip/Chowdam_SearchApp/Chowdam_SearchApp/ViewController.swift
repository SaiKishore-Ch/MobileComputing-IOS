//
//  ViewController.swift
//  Chowdam_SearchApp
//
//  Created by Student on 03/03/22.
//



import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
   
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var prevButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    var arr = [["car1","car2","car3","car4","car5"],["flower1","flower2","flower3","flower4","flower5"],["animal1","animal2","animal3","animal4","animal5"],["bg","404"]]
    
    var cars = ["cars","car","ferrari","mclaren","range rover","benz","porsche"]
    
    var flowers = ["flowers","flower","sunflower","chrysanthemum","hibiscus","rose","marigold"]
    
    var animals = ["animals","animal", "lion","tiger","elephant","deer","zebra"]
    
    var topic = 0
    var image1:Int!
    var image2:Int!
    var image3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        prevButton.isHidden = true
        nextButton.isHidden = true
        searchButton.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
        
    }
    
        
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
            searchButton.isEnabled = false
            
        }
        else{

            prevButton.isEnabled = false
            nextButton.isEnabled = false
            searchButton.isEnabled = true
            resetButton.isHidden = false
    }
    }
    
        
        
    
    
    var car = [["ferrari","mclaren","range rover","benz","porsche"],["Ferrari S.p.A. is an Italian luxury sports car manufacturer based in Maranello, Italy. Founded by Enzo Ferrari in 1939 from the Alfa Romeo racing division as Auto Avio Costruzioni, the company built its first car in 1940, and produced its first Ferrari-badged car in 1947.","McLaren Racing Limited is a British motor racing team based at the McLaren Technology Centre in Woking, Surrey, England. McLaren is best known as a Formula One constructor, the second oldest active team, and the second most successful Formula One team after Ferrari, having won 183 races, 12 Drivers' Championships and 8 Constructors' Championships. McLaren also has a history of competing in American open wheel racing, as both an entrant and a chassis constructor, and has won the Canadian-American Challenge Cup (Can-Am) sports car racing championship. The team is a subsidiary of the McLaren Group, which owns a majority of the team.","The Rover Company (originator of the Land Rover marque) was experimenting with a larger model than the Land Rover Series in 1951, when the Rover P4-based two-wheel-drive Road Rover project was developed by Gordon Bashford.This was shelved in 1958 and the idea lay dormant until 1966, when engineers Spen King and Bashford set to work on a new model.","Mercedes-Benz (German pronunciation:(audio speaker iconlisten)), commonly referred to as just Mercedes, is a German luxury automotive marque. Both Mercedes-Benz and Mercedes-Benz AG (a Mercedes-Benz Group subsidiary established in 2019) are headquartered in Stuttgart, Baden-Württemberg, Germany. Mercedes-Benz produces consumer luxury vehicles and commercial vehicles. Its first Mercedes-Benz-badged vehicles were produced in 1926. In 2018, Mercedes-Benz was the largest seller of premium vehicles in the world, having sold 2.31 million passenger cars.","Dr.-Ing. h.c. F. Porsche AG, usually shortened to Porsche (German pronunciation: [ˈpɔɐ̯ʃə] (audio speaker iconlisten); see below), is a German automobile manufacturer specializing in high-performance sports cars, SUVs and sedans, headquartered in Stuttgart, Baden-Württemberg, Germany. The company is owned by Volkswagen AG, a controlling stake of which is owned by Porsche Automobil Holding SE."]]
    
    var flower = [["sunflower","chrysanthemum","hibiscus","rose","marigold"],["Helianthus is a genus comprising about 70 species of annual and perennial flowering plants in the daisy family Asteraceae.Except for three South American species, the species of Helianthus are native to North America and Central America. The common names sunflower and common sunflower typically refer to the popular annual species Helianthus annuus, whose round flower heads in combination with the ligules look like the Sun.","Chrysanthemums, sometimes called mums or chrysanths, are flowering plants of the genus Chrysanthemum in the family Asteraceae. They are native to East Asia and northeastern Europe. Most species originate from East Asia and the center of diversity is in China.Countless horticultural varieties and cultivars exist.","Hibiscus is a genus of flowering plants in the mallow family, Malvaceae. The genus is quite large, comprising several hundred species that are native to warm temperate, subtropical and tropical regions throughout the world. Member species are renowned for their large, showy flowers and those species are commonly known simply as hibiscus, or less widely known as rose mallow. Other names include hardy hibiscus, rose of sharon, and tropical hibiscus","A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars.[citation needed] They form a group of plants that can be erect shrubs, climbing, or trailing, with stems that are often armed with sharp prickles.","Marigold use in these celebrations is believed to be tied to a romantic Aztec origin myth about two lovers, Xótchitl and Huitzilin. According to the legend, the lovers would often hike to the top of a mountain to leave flower offerings for the sun-god Tonatiuh, and to swear their love and commitment to one another."]]

    var animal = [["lion","tiger","elephant","deer","zebra"],["The lion (Panthera leo) is a large cat of the genus Panthera native to Africa and India. It has a muscular, deep-chested body, short, rounded head, round ears, and a hairy tuft at the end of its tail. It is sexually dimorphic; adult male lions are larger than females and have a prominent mane. It is a social species, forming groups called prides.","The tiger (Panthera tigris) is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside. An apex predator, it primarily preys on ungulates such as deer and wild boar. It is territorial and generally a solitary but social predator, requiring large contiguous areas of habitat, which support its requirements for prey and rearing of its offspring.","Elephants are the largest existing land animals. Three living species are currently recognised: the African bush elephant, the African forest elephant, and the Asian elephant. They are an informal grouping within the proboscidean family Elephantidae. Elephantidae is the only surviving family of proboscideans; extinct members include the mastodons. Elephantidae also contains several extinct groups, including the mammoths and straight-tusked elephants.","Deer or true deer are hoofed ruminant mammals forming the family Cervidae. The two main groups of deer are the Cervinae, including the muntjac, the elk (wapiti), the red deer, and the fallow deer; and the Capreolinae, including the reindeer (caribou), white-tailed deer, the roe deer, and the moose. Male deer of all species (except the Chinese water deer) as well as female reindeer, grow and shed new antlers each year.","Zebras (UK: /ˈzɛbrəz/, US: /ˈziːbrəz/) (subgenus Hippotigris) are African equines with distinctive black-and-white striped coats. There are three living species: the Grévy's zebra (Equus grevyi), plains zebra (E. quagga), and the mountain zebra (E. zebra). Zebras share the genus Equus with horses and asses, the three groups being the only living members of the family Equidae. Zebra stripes come in different patterns, unique to each individual. Several theories have been proposed for the function of these stripes, with most evidence supporting them as a deterrent for biting flies."]]
    
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        image1 = 0
        image2 = 0
        image3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        prevButton.isHidden = false
        nextButton.isHidden = false
        prevButton.isEnabled = false
        nextButton.isEnabled = false
        resetButton.isEnabled = true
        if(cars.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[0][image1])
            
            topic = 1
            topicInfoText.text = car[1][text1]
        }
        else if(flowers.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[1][image2])
            
            topic = 2
            topicInfoText.text = flower[1][text2]
        }
        else if(animals.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[2][image3])
            
            topic = 3
            topicInfoText.text = animal[1][text3]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])

            topicInfoText.text = nil
            
            prevButton.isHidden = true
            nextButton.isHidden = true
            resetButton.isEnabled = true
        }
        
        
    }
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
        if(topic == 1){
            image1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: image1)
        }
        if(topic == 2){
            image2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: image2)
        }
        if(topic == 3){
            image3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: image3)
        }
        
    }
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        if(topic == 1){
            image1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: image1)
        }
        if(topic == 2){
            image2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: image2)
        }
        if(topic == 3){
            image3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: image3)
        }
    }
    
    
    @IBAction func resetButton(_ sender: Any) {
        
        prevButton.isHidden = true
        nextButton.isHidden = true
        topicInfoText.text = nil
        resetButton.isHidden = true
        searchTextField.text = ""
        resultImage.image = UIImage(named: arr[3][0])

        searchButton.isEnabled=false
        
        
    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if image1 == arr[0].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][image1])
                
                topicInfoText.text = car[1][text1]
            }
            else if(image1 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][image1])
                
                topicInfoText.text = car[1][text1]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][image1])
               
                topicInfoText.text = car[1][text1]
            }
        }
        if(topic == 2){
            if image2 == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][image2])
                
                topicInfoText.text = flower[1][text2]
            }
            else if(image2 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][image2])
                
                topicInfoText.text = flower[1][text2]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][image2])
                
                topicInfoText.text = flower[1][text2]
                
            }
        }
        if(topic == 3){
            if image3 == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][image3])
                
                topicInfoText.text = animal[1][text3]
            }
            else if(image3 == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][image3])
                
                topicInfoText.text = animal[1][text3]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][image3])
                
                topicInfoText.text = animal[1][text3]
                
            }
        }
    }
    

    
    
    
    
    
}


