//
//  ViewController.swift
//  WeatherApplication
//
//  Created by Omtri,Homakesavadurgaprasad on 4/7/22.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var continueButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func continueButtonPressed(_ sender: UIButton) {
    }
    

}

