import UIKit

var greeting = "Hello, playground"

print("HI",12,12.25) //Comma separated gives a space in the o/p

//String Interpolation
var name="Sai Kishore"
var grade=89.92

//Hello, Sai Kishore
print("Hello, \(name)")
print("Hello, \(name)! Your grade is \(grade)")

var proLan="Swift"
print("I like the \(proLan) Programmaing Language")
var age = 23
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")

print("""
Hello
World!
""")

// \r carriage return
print ("Hello All,\rWelcome to Swift programming")
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")

print("The list of numbers are ", terminator : "-----")
print(1,2,3,4,5,6)
print("The new pattern is", terminator : " ")
print(1,2,3,4,5,6, separator: " is to ")


var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)
